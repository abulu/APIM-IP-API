using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

namespace GetRefershToken
{
    class Program
    {
        static void Main(string[] args)
        {
            // The code provided will print ‘Hello World’ to the console.
            // Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.
            Console.WriteLine("Hello World!");

            string cookie = "AQABAAQAAAAm-06blBE1TpVMil8KPQ417TA6e55-OYEaGC2Y05SyXxXeqx5l5s9ppo6bsieZQXQuD570ePBGulznd7-0slRNz6cSZZY85tqRrFkILDcBaqSW2yzMkwewsD9g28QnvjSOaXPiH_JvH0OK_o4zIXIdlCgOYiN22L8ls3hG9FJzd5p2fq93DM2LLDJ_fHZfm91UeRTlhHMhH02J-cI64io2wL0sye4bmD4NQ7ihWT404j0_AK_2vMaV7ne_afY1tDtSEtojYbdmHL4TZ7JUEZNmquMjcuMeYJDM1phxOr7v3HYk14XOuLq2aHZ93jWi6mw_GLP173_F47zS9BtOl5Cdc_GGqHxQpm6VVbOmdEJsXvZqgJmk9PHqumoCpPAwefD19DwEOJtToNQp3VUht9ibbRKr0J5AjZl4iJwpXjHyuCQbfijVEmDK3Lk4Zc0x5L3vV3b7b0dXvf8A0GruOw1GAWs2Zv-tc7HDRiySvt3OKMa3LIp2bGX1m1S_24fUBNT4IVMpCopTIb2Z2w_Hw0dOyrYk-5VRPGpikO57BFKAIB2F4EKaKUhSgcvK-XjlNPRe6CfdGkpai3Xmk2jVsgUGp9vJ8yS5DB0JP8zTr4_c9uIJn2Cfi8D7jasmG00r9KQZTDVKOCypfK6ubaS_EWt3-U1Ve5Fj1TrndKMFgc0ACQesoEX6NFDphBj2RmYa4iwDD3xTxtGWUkJVdV1Q-ULaSKKoJIXdbjfsmvG_eLWD3UC0SFpG__tcO2ZumZUKAMI1UIK_jnC1MTx7kpDRHEe74_8EJpnkf0IuPtMGxedET9l6H20iOUM0_sfrd0Ax2fixLvAmrcaE-1ixWycN_1rpIAAgAEAA8AEAAA";

            CookieBasedAuthenticationProvider provider = new CookieBasedAuthenticationProvider(cookie);

            string token = provider.RefreshAccessToken().Result;

            Console.WriteLine($"Token :{token}");

            Console.ReadKey();

            // Go to http://aka.ms/dotnet-get-started-console to continue learning how to build a console app! 
        }
    }

    public class CookieBasedAuthenticationProvider
    {
        internal static readonly string SDLoginUrlFormat = "https://login.microsoftonline.com/common/oauth2/authorize?response_type={0}&client_id={1}&redirect_uri={2}&state=e5e7271e-842a-4faf-89d6-43f06cf33b17&nux=1&domain_hint=common&client-request-id=289fd29d-d92c-4e64-b0c5-f2d63de06a67&x-client-SKU=Js&x-client-Ver=1.0.13&nonce={3}";

        private string cachedToken;

        private CookieContainer cookieContainer;

        public CookieBasedAuthenticationProvider(string cookie)
        {
            cookieContainer = new CookieContainer();
            cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("AADSSO", "NA|NoExtension"));
            //// Store the cookie somewhere else later
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ESTSAUTHPERSISTENT", cookie));


            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ESTSSSOTILES", "1"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("brcap", "0"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("stsservicecookie", "estsfd"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ESTSAUTHLIGHT", "+56d402af-9c3b-4269-ac1e-97c7e1ca35b3"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ESTSSC", "00"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("esctx", "AQABAAAAAAAm-06blBE1TpVMil8KPQ41KRx4g0donu7xTSgL2ypn0GkEt0XaMUl73TDtP2ke7Vke80K8ZLdseXisezYN4GSkjlcEDeTl7inaj8aF2oX8M-dUDYMBt7rDNycyrKjrDFuwSa1NtpXr5SGBR-TPhV0CYg5jNRXa9Zo-7wHadu3l6tg-U9mkBaagq66b7FLO1WkgAA"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("x-ms-RefreshTokenCredential", "eyJhbGciOiJIUzI1NiIsICJjdHgiOiJYZEx3Z0FleWV1S1JvRWpcL2pCcDEwRVZSQmpHem10SEwifQ.eyJyZWZyZXNoX3Rva2VuIjoiMC5BUm9BdjRqNWN2R0dyMEdScXkxODBCSGJSNGM3cWpodG9CZElzblY2TVdtSTJUc2FBQ0EuQVFBQkFBQUFBQUFtLTA2YmxCRTFUcFZNaWw4S1BRNDE5NU94MzRiSlFUZ2hCZU1weGlEMHRjamlxRnVnX0dFbVdlTGYyUnJiSXlMN2NmVjFoMW9oLVVURzFwSjhGUEg4bk1kTWJhaTlnM3NBSEZIal94cmdTeWRCUGtEVXM1YXZhVXNvNElIQ3VSUlAtOGJQWnlybFNkMjc0VjBfRmVHOHVtekxyenJ1REdDQzdrQ3M3akpsZklwdzJZYW5vZzFpT3VXTEpfcjZDUEprblA0anh6N284SnJSbzUxSGxwOEdjZDVvOUMwd0FwZFBYZlE1VzdTYm5WOFMxODZ5bDR2VG84aWhSaDk3ckxKVE5MN210Z2VJS2R5N3BFTWxqcVZkeFJ5OFhlb283U1FaYU5VMzFHSnBYVnFkS3MxY0FnV2pCWTMyYzJrTFRQRGlMT3B0d3Y0c2tFUmcxcEYtY2ROTl9YdXlxelNFcURQLTdUWDQ5SWNqRGtRU05ZVDUtVFl1OEhsM2NhMXNhUXRpY01hU1pnT1RIVFFZcVduM3dPRzR2LXBfNXlOeXQ4eE8zMm9PX3h0dkx4SndHNG8zUXl0SHJfRzVSYV95ZzhfUUI2Z3d0NHBXSjNESWEzdndJU0ZsdV9IR2JNVF9oLVdWVGtvR3pHYVllaXNheGdsUGtLUjF3ZUc5dHl4NFVPNHF1dVc0TWo1MVhhUFAtdXVuT2ZQRXZnblRzRFZDVTNxUi0wbFVPVXZTS3A0aXhyVXlwOEEwY0djV3VTT3V2TEhkY3BOZnNVTUpYRTZvaDFDU3d5TDh2MWc1d0UyQUhxVG9OZkgtdGUzRnhERXZqYUl4SGtlY0dCYXhhdl9reEZsX2dUUTJ2VFByMDBJanF0Tm9nRDdGVWRodGJVZXp6QzRZWDhpR3lVX3FjSFhsS0hKSlFSU21tOVJPd3RaTTRxQmJuZWRjcUV4OWhZUm54ZGY5eXFfeFFaeHhOZFlnUFZzRWpLbURYTU1yVlJxZWxrZXpmaTZlWXVpTGVTc29seDZvdkI2em9YTy1ybU5nM0d4NXhsSmRCM1ZpWUlxelJkU3c3UkxveXZRckc1blNwM0tYQnlKMzVHUHFDSkVsVzBZN3pBSHdWU05HQ2pKbjNyWV8zNUpfTXhyblZwZjZLQU13cHJGTGZxWW1TUHNBLUFyOXlOaDdWZ3BlYVUtUk8zY2xXb2pZVmU2RFFaNXc1bF9vbWgxR3h3WUJGY2hMeVR1Sy04VG9GMG1qMkRWaFd2azJuT0NnTENGNmpyYkl3VURKamhzYXhDVURoS2FNUk52M0phMTEyQmVUTXFLMzJGTWhMRUE1TU1jNXBpcFJOM08tOUQ4Z1lBSW5qYUowaVpuWlE4SVBhN3BiSHVWd1BGWU9ZcUJXTEY5U1liSlJ5VGQ0ei1SR1owelQzNUtjT2pJRHRjazUxclZvT1ExZTRWMF9wcUdhUFJubk12TFBzT2FUeUkzb0lBQSIsICJpc19wcmltYXJ5IjoidHJ1ZSIsICJyZXF1ZXN0X25vbmNlIjoiQVFBQkFBQUFBQUFtLTA2YmxCRTFUcFZNaWw4S1BRNDFPSmhLUmJ4V29XYkVnbWVoVzBRTFpPMTBnY3B5TWc0NGpSM0dXaF9ja0h6U0dHSFpyU3liQkZaUjREaXJ3b2Y0TXd5UHhiZ0RFdm5nS3RCdkpoQkg2aUFBIn0.DDztHkLR3x5dmdS7hr-pHLF17f7ImPEMPfNkDU2PXPg"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("clrc", "{%2218391%22%3a[%22xA1e9lwy%22%2c%22CI/ktETU%22]%2c%2218403%22%3a[%229JSpjMFX%22%2c%22qxQa3+bw%22]%2c%2218404%22%3a[%22ziKdgxpE%22%2c%22CixJmTQ4%22]}"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("x-ms-gateway-slice", "estsfd"));
            cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ESTSAUTHPERSISTENT", "0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AgABAAQAAAAm-06blBE1TpVMil8KPQ41AADs_wEA9P-gPU-etm9uUnQwNz42LTXTOBzjXl4WCO3C8cam2hanvM7upZVK_13mvyXysdQLc2mgW-zjg-wFoFWUy6igL5XjaL_5TaVTaI8jrym13JFhhlYKT-UJwk2vhpV3Hc-uBqV9oo594NfPYT4yPtF46_eigGxDp0oyifXXUKfgNsZOASsek21DFeIA9FgJtsSEifv4KylcZnEfqR70X0PtvY7yCuIN4xJZ0qQ4ahxyxv44llEpcVnr15hbqdIWVF2C8bFhE9TBGKN0NUjf1s_GK97c6W0goOnRRmi_A8mw2TY1MQlfaI3Wp_Jrb1oeUrqjNimoiwUDCdkxoD5Dmnku9niChdzSE2ojR4z1MwKffiihewui3X8cDsdGH-vMyWHcoe_rbremY2IhtrcRa7O767LRSuGcuhwQWJYYj-UcNNLZIGWIAqhx0HZXBkgH18RQEykbZeeCipaYfNEqyUbZW3g14CG6XnbLu_ZcXxaS4vdlw9kp5d2PunC9lVwmIZNSCQfzWYQ-1N_xrTtMguosZ-T_dA2L_Vwc7ExHabXpU9dQEIk7EF4VxF7giUM4saxUPUbXwYPP_8AuVMhAb2ytq_JiK9XbcixoQVLx6Gf3z4_QJWYDleya_BRku0aqp32KnVo0yD6dj6jVR2aOsT9CtcZRNxsWGL7FMNbDA4_0ECf60TRgwqjDeslGbEkwMQwH1DSw6HlqV3EttVuXNA"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ESTSAUTH", "0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AgABAAQAAAAm-06blBE1TpVMil8KPQ41AADs_wEA9P-qnz0B8ERkvR4iJfRNUwTpty5I2swiXbGL4nWGpTCGhUqOBqv68wlAskMsnpkH-YHLhi9DLi8sow"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ch", "yuxTKJwIi2WqWu1NU9gUzDMOZ8OERil3gIb1WS8O8NQ"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("buid", "0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AQABAAEAAAAm-06blBE1TpVMil8KPQ41MHq6gTOl_F--2PeRadAoeUiAbuHicpfcYKarZ3F0SKFgQKrQ8KZIiVnw3oP0Vn0TXQsZ1qf3tc35W9XJRP19umeCPjtABcFxdNEP4cE_ZqMPM6AV8hfytC9eTWSbDfm875yKVsEqQnH6XzRtHaDgOKs2cHdEmN4dqnGNcHse-dEgAA"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("CCState", "Q2s4S08ySjFiSFZBYldsamNtOXpiMlowTG1OdmJYeGhjSEE2TURBd01EQXdNREl0TURBd01DMHdabVl4TFdObE1EQXRNREF3TURBd01EQXdNREF3RWdFQUdna0pCZWpVZmZqKzEwZzRBRWdCQ2s4S08ySjFiSFZBYldsamNtOXpiMlowTG1OdmJYeGhjSEE2TlRaaVl6QTBOR010TnpZME5DMDBZbVUyTFdKak5USXRNemRrTVRjNFlqVmhOalF3RWdFQUdna0o3TFJGeXczKzEwZzRBVWdCRWhJS0VDamZuMi9jNEFsUG1mbWJ6U256T1dBYUNRbm12RlNBRHY3WFNDSjZBUUFCQUFFQUFBQW0rMDZibEJFMVRwVk1pbDhLUFE0MTBzcFhvVEtQeTZZcjBEZnorUERlNWtmMGlacjJoVFpqYmpKcjY4TzlKZE1HVTQ0aEJTUkE2bnRuZ1QzQnJKR0lhRVNnRDdHTFlUNXU0bFRtMkIyRFFTTUFuOUh6dStjZ2wwK05pZjdrYjFpMXpuakIxeUg4WEVEZ2JYK1g3d3JuSUFBcXpRVUJBQUVBQVFBQUFOQUErQkJQT0F0dXV0QmZkOXdkQWdjd2dnR3ZCZ2txaGtpRzl3MEJCd09nZ2dHZ01JSUJuQUlCQURHQ0FVZ3dnZ0ZFQWdFQU1Dd3dGVEVUTUJFR0ExVUVBeE1LVFZOSlZDQkRRU0JhTWdJVGJRQ1ovWUUrYkZpcmw1UHc3QUFCQUpuOWdUQU5CZ2txaGtpRzl3MEJBUUVGQUFTQ0FRQWl5MGhFdWJvRkJvaXlWWjlVVXlBbVJSR2pjSUFzbWtlaXMvR2w1c3N5RjBwQk1lM3dwMDVmM2I3bG1yaWhWUjFnNVl2SkMrTmxnTXFDOWtCRkFNWHFUdzB4czVwU2h4TUpLQU1JaEZwUjA5V2xVT1Frek1qeEJ2OU4rcjIxeFVPV0h0OXE4ZEs1Rk11QkRGR2FkYXJRRXAzN2cyQS9nZDF2NFBMZWxHdFBwMWFYaUF1NHc4NkF1SjJCamF2eFFVZHNFRVdjVUY3ZTZTT1ZNcEpDZDBHOHFkTXB0NTdVQjNpUjgyNnQ0dGlRcGllTnVQTDRsR1lLbzJ5S25xaXZRK3orWTN0R0dxM1paWnNPVlluc21xVjJQWVRxSW55SWZLdmZTa1VRck5Ed3BRQ1pDRDg0ZityRUhXOGZBU2RRSEJmZlhBVzBLVExxTHF5Z1RaVThleWkvTUVzR0NTcUdTSWIzRFFFSEFUQVVCZ2dxaGtpRzl3MERCd1FJaU55ZldHSFpKSnlBS0hZSVZVVTh4U0h2NEVIb0JjT29lYUFXL3hjYW1wblJVRXBLSm1tM0QwOGQ5bkswZm5sV0lRR2pjbkw2UmtpOGdiSE9WV0JlbTZhOWdIY1k2MFBHV3U2RXBXUHFJZHVTVFFHWTFQb0toTGRUcEt1L25CeWU5eE5mb09Dc3IycGpOOWpvTnc5WUVzSDI3aXhNKzc2cHBBanFNbXJXMU5Vb1dkZzA3V0xBcnVDSWMwejdsU2pQUGRCNUJ6VU5XeC9BbGd6UktxcFBxRFA4eGhBZWxkUDVUSElMc0dUa1RFL0ZGdnZSbkNyOFBJMldSSDRwWnBLbzdXWjNxdDY1Q0NFdk5GQzluMFVKaFFWRVorTVczVFRUZzBRRFZ2bGxNRk5FS2RaQlZjV2Y1Y3U0YlZuMkNTY2ZYL1hXenRGcUN0VnJlUmMzc29CUm1UMm15QW5GZ2oyTXlFc25JTW9McUUrSm1KNDY0V08vSE1uNGJMZEZnanU5d3phNUYvZldCL09nWXpia0hmbEJ0V2p4QUFFPQ=="));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("SignInStateCookie", "CAQABAAIAAAAm-06blBE1TpVMil8KPQ41BAMezyGG0nU4f6eTRqvqDUz8qETzYB3TS3AePf79o-YRbz8t1x5GbwEk3F8axItBhHHTj6IN0Li20GHIP63z-KAAaihUSaHQLbSxdtp0FA2LGrFitsLeRwO48ZWemejcMN74o0bZa4dCYx8C_7nBwqyi0M20dBG7U_pVMg03vgSSBtVP789pCbeNm7PGTLukKZ6LXA5xB5RzSI7ccmXU9JNjTuC-8vxN8qYgWZmMLj1jnwjd2j8jJ3W-Tj2CCYXGHqDp3Q3nGZ8lZ4emlhuafGqRubHjE2E-N39nI4udq3vdmo2WI5wA9zTUPFCuesoO08C-Bsv2uZPJK25YmrYBpoe6o9uZzCzp2NfkwXrGL4rKhKfk9l9E7UtuC9PZE6iTwfv8dgdJGHJzw38Qe9F41aoILo1N7yFKEArE8prXUrYBRuxvIo9sbGyh9hT0lUaMcH8Ww8RKpa-7xZ2gPYhAJVDtTFZR8RezyYVCP-fvbAggAA"));
            //cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("fpc", "AvwERYSgRkdHva1Cfuc0yZDIGZlQAgAAAD9bWdYOAAAA4ZikJQEAAACQW1nWDgAAAMkJJlcCAAAArFtZ1g4AAAA"));





            //ESTSSSOTILES=1; 
            //brcap=0; 
            //stsservicecookie=estsfd; 
            //ESTSAUTHLIGHT=+56d402af-9c3b-4269-ac1e-97c7e1ca35b3; 
            //ESTSSC=00; 
            //esctx=AQABAAAAAAAm-06blBE1TpVMil8KPQ41KRx4g0donu7xTSgL2ypn0GkEt0XaMUl73TDtP2ke7Vke80K8ZLdseXisezYN4GSkjlcEDeTl7inaj8aF2oX8M-dUDYMBt7rDNycyrKjrDFuwSa1NtpXr5SGBR-TPhV0CYg5jNRXa9Zo-7wHadu3l6tg-U9mkBaagq66b7FLO1WkgAA; 
            //x-ms-RefreshTokenCredential=eyJhbGciOiJIUzI1NiIsICJjdHgiOiJYZEx3Z0FleWV1S1JvRWpcL2pCcDEwRVZSQmpHem10SEwifQ.eyJyZWZyZXNoX3Rva2VuIjoiMC5BUm9BdjRqNWN2R0dyMEdScXkxODBCSGJSNGM3cWpodG9CZElzblY2TVdtSTJUc2FBQ0EuQVFBQkFBQUFBQUFtLTA2YmxCRTFUcFZNaWw4S1BRNDE5NU94MzRiSlFUZ2hCZU1weGlEMHRjamlxRnVnX0dFbVdlTGYyUnJiSXlMN2NmVjFoMW9oLVVURzFwSjhGUEg4bk1kTWJhaTlnM3NBSEZIal94cmdTeWRCUGtEVXM1YXZhVXNvNElIQ3VSUlAtOGJQWnlybFNkMjc0VjBfRmVHOHVtekxyenJ1REdDQzdrQ3M3akpsZklwdzJZYW5vZzFpT3VXTEpfcjZDUEprblA0anh6N284SnJSbzUxSGxwOEdjZDVvOUMwd0FwZFBYZlE1VzdTYm5WOFMxODZ5bDR2VG84aWhSaDk3ckxKVE5MN210Z2VJS2R5N3BFTWxqcVZkeFJ5OFhlb283U1FaYU5VMzFHSnBYVnFkS3MxY0FnV2pCWTMyYzJrTFRQRGlMT3B0d3Y0c2tFUmcxcEYtY2ROTl9YdXlxelNFcURQLTdUWDQ5SWNqRGtRU05ZVDUtVFl1OEhsM2NhMXNhUXRpY01hU1pnT1RIVFFZcVduM3dPRzR2LXBfNXlOeXQ4eE8zMm9PX3h0dkx4SndHNG8zUXl0SHJfRzVSYV95ZzhfUUI2Z3d0NHBXSjNESWEzdndJU0ZsdV9IR2JNVF9oLVdWVGtvR3pHYVllaXNheGdsUGtLUjF3ZUc5dHl4NFVPNHF1dVc0TWo1MVhhUFAtdXVuT2ZQRXZnblRzRFZDVTNxUi0wbFVPVXZTS3A0aXhyVXlwOEEwY0djV3VTT3V2TEhkY3BOZnNVTUpYRTZvaDFDU3d5TDh2MWc1d0UyQUhxVG9OZkgtdGUzRnhERXZqYUl4SGtlY0dCYXhhdl9reEZsX2dUUTJ2VFByMDBJanF0Tm9nRDdGVWRodGJVZXp6QzRZWDhpR3lVX3FjSFhsS0hKSlFSU21tOVJPd3RaTTRxQmJuZWRjcUV4OWhZUm54ZGY5eXFfeFFaeHhOZFlnUFZzRWpLbURYTU1yVlJxZWxrZXpmaTZlWXVpTGVTc29seDZvdkI2em9YTy1ybU5nM0d4NXhsSmRCM1ZpWUlxelJkU3c3UkxveXZRckc1blNwM0tYQnlKMzVHUHFDSkVsVzBZN3pBSHdWU05HQ2pKbjNyWV8zNUpfTXhyblZwZjZLQU13cHJGTGZxWW1TUHNBLUFyOXlOaDdWZ3BlYVUtUk8zY2xXb2pZVmU2RFFaNXc1bF9vbWgxR3h3WUJGY2hMeVR1Sy04VG9GMG1qMkRWaFd2azJuT0NnTENGNmpyYkl3VURKamhzYXhDVURoS2FNUk52M0phMTEyQmVUTXFLMzJGTWhMRUE1TU1jNXBpcFJOM08tOUQ4Z1lBSW5qYUowaVpuWlE4SVBhN3BiSHVWd1BGWU9ZcUJXTEY5U1liSlJ5VGQ0ei1SR1owelQzNUtjT2pJRHRjazUxclZvT1ExZTRWMF9wcUdhUFJubk12TFBzT2FUeUkzb0lBQSIsICJpc19wcmltYXJ5IjoidHJ1ZSIsICJyZXF1ZXN0X25vbmNlIjoiQVFBQkFBQUFBQUFtLTA2YmxCRTFUcFZNaWw4S1BRNDFPSmhLUmJ4V29XYkVnbWVoVzBRTFpPMTBnY3B5TWc0NGpSM0dXaF9ja0h6U0dHSFpyU3liQkZaUjREaXJ3b2Y0TXd5UHhiZ0RFdm5nS3RCdkpoQkg2aUFBIn0.DDztHkLR3x5dmdS7hr-pHLF17f7ImPEMPfNkDU2PXPg; 
            //clrc={%2218391%22%3a[%22xA1e9lwy%22%2c%22CI/ktETU%22]%2c%2218403%22%3a[%229JSpjMFX%22%2c%22qxQa3+bw%22]%2c%2218404%22%3a[%22ziKdgxpE%22%2c%22CixJmTQ4%22]}; 
            //x-ms-gateway-slice=estsfd; 
            //ESTSAUTHPERSISTENT=0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AgABAAQAAAAm-06blBE1TpVMil8KPQ41AADs_wEA9P-gPU-etm9uUnQwNz42LTXTOBzjXl4WCO3C8cam2hanvM7upZVK_13mvyXysdQLc2mgW-zjg-wFoFWUy6igL5XjaL_5TaVTaI8jrym13JFhhlYKT-UJwk2vhpV3Hc-uBqV9oo594NfPYT4yPtF46_eigGxDp0oyifXXUKfgNsZOASsek21DFeIA9FgJtsSEifv4KylcZnEfqR70X0PtvY7yCuIN4xJZ0qQ4ahxyxv44llEpcVnr15hbqdIWVF2C8bFhE9TBGKN0NUjf1s_GK97c6W0goOnRRmi_A8mw2TY1MQlfaI3Wp_Jrb1oeUrqjNimoiwUDCdkxoD5Dmnku9niChdzSE2ojR4z1MwKffiihewui3X8cDsdGH-vMyWHcoe_rbremY2IhtrcRa7O767LRSuGcuhwQWJYYj-UcNNLZIGWIAqhx0HZXBkgH18RQEykbZeeCipaYfNEqyUbZW3g14CG6XnbLu_ZcXxaS4vdlw9kp5d2PunC9lVwmIZNSCQfzWYQ-1N_xrTtMguosZ-T_dA2L_Vwc7ExHabXpU9dQEIk7EF4VxF7giUM4saxUPUbXwYPP_8AuVMhAb2ytq_JiK9XbcixoQVLx6Gf3z4_QJWYDleya_BRku0aqp32KnVo0yD6dj6jVR2aOsT9CtcZRNxsWGL7FMNbDA4_0ECf60TRgwqjDeslGbEkwMQwH1DSw6HlqV3EttVuXNA; 
            //ESTSAUTH=0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AgABAAQAAAAm-06blBE1TpVMil8KPQ41AADs_wEA9P-qnz0B8ERkvR4iJfRNUwTpty5I2swiXbGL4nWGpTCGhUqOBqv68wlAskMsnpkH-YHLhi9DLi8sow; 
            //ch=yuxTKJwIi2WqWu1NU9gUzDMOZ8OERil3gIb1WS8O8NQ; 
            //buid=0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AQABAAEAAAAm-06blBE1TpVMil8KPQ41MHq6gTOl_F--2PeRadAoeUiAbuHicpfcYKarZ3F0SKFgQKrQ8KZIiVnw3oP0Vn0TXQsZ1qf3tc35W9XJRP19umeCPjtABcFxdNEP4cE_ZqMPM6AV8hfytC9eTWSbDfm875yKVsEqQnH6XzRtHaDgOKs2cHdEmN4dqnGNcHse-dEgAA; 
            //CCState=Q2s4S08ySjFiSFZBYldsamNtOXpiMlowTG1OdmJYeGhjSEE2TURBd01EQXdNREl0TURBd01DMHdabVl4TFdObE1EQXRNREF3TURBd01EQXdNREF3RWdFQUdna0pCZWpVZmZqKzEwZzRBRWdCQ2s4S08ySjFiSFZBYldsamNtOXpiMlowTG1OdmJYeGhjSEE2TlRaaVl6QTBOR010TnpZME5DMDBZbVUyTFdKak5USXRNemRrTVRjNFlqVmhOalF3RWdFQUdna0o3TFJGeXczKzEwZzRBVWdCRWhJS0VDamZuMi9jNEFsUG1mbWJ6U256T1dBYUNRbm12RlNBRHY3WFNDSjZBUUFCQUFFQUFBQW0rMDZibEJFMVRwVk1pbDhLUFE0MTBzcFhvVEtQeTZZcjBEZnorUERlNWtmMGlacjJoVFpqYmpKcjY4TzlKZE1HVTQ0aEJTUkE2bnRuZ1QzQnJKR0lhRVNnRDdHTFlUNXU0bFRtMkIyRFFTTUFuOUh6dStjZ2wwK05pZjdrYjFpMXpuakIxeUg4WEVEZ2JYK1g3d3JuSUFBcXpRVUJBQUVBQVFBQUFOQUErQkJQT0F0dXV0QmZkOXdkQWdjd2dnR3ZCZ2txaGtpRzl3MEJCd09nZ2dHZ01JSUJuQUlCQURHQ0FVZ3dnZ0ZFQWdFQU1Dd3dGVEVUTUJFR0ExVUVBeE1LVFZOSlZDQkRRU0JhTWdJVGJRQ1ovWUUrYkZpcmw1UHc3QUFCQUpuOWdUQU5CZ2txaGtpRzl3MEJBUUVGQUFTQ0FRQWl5MGhFdWJvRkJvaXlWWjlVVXlBbVJSR2pjSUFzbWtlaXMvR2w1c3N5RjBwQk1lM3dwMDVmM2I3bG1yaWhWUjFnNVl2SkMrTmxnTXFDOWtCRkFNWHFUdzB4czVwU2h4TUpLQU1JaEZwUjA5V2xVT1Frek1qeEJ2OU4rcjIxeFVPV0h0OXE4ZEs1Rk11QkRGR2FkYXJRRXAzN2cyQS9nZDF2NFBMZWxHdFBwMWFYaUF1NHc4NkF1SjJCamF2eFFVZHNFRVdjVUY3ZTZTT1ZNcEpDZDBHOHFkTXB0NTdVQjNpUjgyNnQ0dGlRcGllTnVQTDRsR1lLbzJ5S25xaXZRK3orWTN0R0dxM1paWnNPVlluc21xVjJQWVRxSW55SWZLdmZTa1VRck5Ed3BRQ1pDRDg0ZityRUhXOGZBU2RRSEJmZlhBVzBLVExxTHF5Z1RaVThleWkvTUVzR0NTcUdTSWIzRFFFSEFUQVVCZ2dxaGtpRzl3MERCd1FJaU55ZldHSFpKSnlBS0hZSVZVVTh4U0h2NEVIb0JjT29lYUFXL3hjYW1wblJVRXBLSm1tM0QwOGQ5bkswZm5sV0lRR2pjbkw2UmtpOGdiSE9WV0JlbTZhOWdIY1k2MFBHV3U2RXBXUHFJZHVTVFFHWTFQb0toTGRUcEt1L25CeWU5eE5mb09Dc3IycGpOOWpvTnc5WUVzSDI3aXhNKzc2cHBBanFNbXJXMU5Vb1dkZzA3V0xBcnVDSWMwejdsU2pQUGRCNUJ6VU5XeC9BbGd6UktxcFBxRFA4eGhBZWxkUDVUSElMc0dUa1RFL0ZGdnZSbkNyOFBJMldSSDRwWnBLbzdXWjNxdDY1Q0NFdk5GQzluMFVKaFFWRVorTVczVFRUZzBRRFZ2bGxNRk5FS2RaQlZjV2Y1Y3U0YlZuMkNTY2ZYL1hXenRGcUN0VnJlUmMzc29CUm1UMm15QW5GZ2oyTXlFc25JTW9McUUrSm1KNDY0V08vSE1uNGJMZEZnanU5d3phNUYvZldCL09nWXpia0hmbEJ0V2p4QUFFPQ==; 
            //SignInStateCookie=CAQABAAIAAAAm-06blBE1TpVMil8KPQ41BAMezyGG0nU4f6eTRqvqDUz8qETzYB3TS3AePf79o-YRbz8t1x5GbwEk3F8axItBhHHTj6IN0Li20GHIP63z-KAAaihUSaHQLbSxdtp0FA2LGrFitsLeRwO48ZWemejcMN74o0bZa4dCYx8C_7nBwqyi0M20dBG7U_pVMg03vgSSBtVP789pCbeNm7PGTLukKZ6LXA5xB5RzSI7ccmXU9JNjTuC-8vxN8qYgWZmMLj1jnwjd2j8jJ3W-Tj2CCYXGHqDp3Q3nGZ8lZ4emlhuafGqRubHjE2E-N39nI4udq3vdmo2WI5wA9zTUPFCuesoO08C-Bsv2uZPJK25YmrYBpoe6o9uZzCzp2NfkwXrGL4rKhKfk9l9E7UtuC9PZE6iTwfv8dgdJGHJzw38Qe9F41aoILo1N7yFKEArE8prXUrYBRuxvIo9sbGyh9hT0lUaMcH8Ww8RKpa-7xZ2gPYhAJVDtTFZR8RezyYVCP-fvbAggAA; 
            //fpc=AvwERYSgRkdHva1Cfuc0yZDIGZlQAgAAAD9bWdYOAAAA4ZikJQEAAACQW1nWDgAAAMkJJlcCAAAArFtZ1g4AAAA

        }

        public async Task AuthenticateRequest(HttpRequestMessage request)
        {
            // Passing tenant ID to the sample auth provider to use as a cache key
            string accessToken = await GetAccessToken();
            // Append the access token to the request
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            // This header identifies the sample in the Microsoft Graph service. If extracting this code for your project please remove.
            // requestMessage.Headers.Add("SampleID", "aspnetcore-connect-sample");
        }

        public async Task<string> GetAccessToken()
        {
            if (!string.IsNullOrEmpty(cachedToken))
            {
                return cachedToken;
            }

            return await RefreshAccessToken();
        }

        public async Task<string> RefreshAccessToken()
        {
            string access_token = "";
            string token_url
                     = @"https://login.microsoftonline.com/common/oauth2/authorize?resource=56bc044c-7644-4be6-bc52-37d178b5a640&response_type=token&state=&client_id=56bc044c-7644-4be6-bc52-37d178b5a640&scope=c8b3e0dd-990b-4882-b119-acddfcaa7ace&redirect_uri=https://servicedesk.microsoft.com/";
        //   string redictUrl = HttpUtility.UrlEncode("https://servicedesk.microsoft.com/");
        //  var token_url = string.Format(SDLoginUrlFormat, "id_token", "56bc044c-7644-4be6-bc52-37d178b5a640", redictUrl, Guid.NewGuid().ToString());

        //https://login.microsoftonline.com/common/oauth2/authorize?resource=56bc044c-7644-4be6-bc52-37d178b5a640&response_type=token&state=&client_id=56bc044c-7644-4be6-bc52-37d178b5a640&scope=c8b3e0dd-990b-4882-b119-acddfcaa7ace&redirect_uri=https%3a%2f%2fservicedesk.microsoft.com%2f&sso_reload=true&sso_nonce=AQABAAAAAAAm-06blBE1TpVMil8KPQ41bb6G80nUelp9Jf11kD4TO-bnqJ8kEwp9UBKvkrde3A3z-vTaygDNUpJWK1DHAPr_M_1nj2FMZ0mAF2mGMTGWPyAA&client-request-id=668cec80-89b5-4180-8045-a0765ae4ed67&mscrid=668cec80-89b5-4180-8045-a0765ae4ed67
            // Get Access Token
            {
                var handler = new HttpClientHandler()
                {
                    CookieContainer = cookieContainer,
                    AllowAutoRedirect = false
                };
                using (HttpClient client = new HttpClient(handler))
                {
                    try
                    {
                        HttpResponseMessage response = await client.GetAsync(token_url);
                        if (response.StatusCode == HttpStatusCode.Redirect)
                        {
                            string responseBody = await response.Content.ReadAsStringAsync();
                            var statuscode = response.StatusCode;
                            var headers = response.Headers;
                            var location = headers.Location;
                            cachedToken = access_token = location?.ToString().Split('=')[1].Split('&')[0];
                        }
                        else
                        {
                            //OnFailedToRefreshToken?.Invoke(this, new FailedToRefreshTokenEventArgs() { Message = "Failed to refresh access token", Exception = new Exception(response.ReasonPhrase) });
                        }
                    }
                    catch (Exception e)
                    {
                        //OnFailedToRefreshToken?.Invoke(this, new FailedToRefreshTokenEventArgs() { Message = "Failed to refresh access token", Exception = e });
                    }

                    client.Dispose();
                }
            }

            return access_token;
        }
    }
}
