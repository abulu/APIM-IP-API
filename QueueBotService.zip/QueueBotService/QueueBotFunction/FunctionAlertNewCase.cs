using System;
using System.Net.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace QueueBotFunction
{
    public static class FunctionAlertNewCase
    {

        private static HttpClient client = new HttpClient();

        [FunctionName("FunctionAlertNewCase")]
        public static void Run([TimerTrigger("0 */5 * * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

            //var caseinfo = "";
            ////https://qbotserver.azurewebsites.net/api/notify/Bu%20Lu?msg=this%20is%20a%20bot
            ////test put the get result to bot service
            ////https://lbmaker-bot.azurewebsites.net/api/notify/
            //var geturl = "https://qbotserver.azurewebsites.net/api/notify/Yuan%20Chen?msg=" + caseinfo.Replace("/", "|");
            //var result = client.GetAsync(geturl).Result;
            //Console.WriteLine($"Get URL : {geturl}");
            //Console.WriteLine($"Get result : {result}");
        }
    }
}
