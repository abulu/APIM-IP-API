﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace QueueBotService
{
    public class CaseInfo
    {

        public string CaseID { get; set; }
        //public string Severity { get; set; }
        //public string ExpiresOn { get; set; }
        private string _servity;
        public string Severity
        {
            get
            {
                if (_servity == "4") return "C";
                else if (_servity == "3") return "B";
                else if (_servity == "4") return "A";
                else return _servity;
            }
            set { _servity = value; }
        }
        private string _expireOn;
        public string ExpiresOn
        {
            get
            {
                try
                {
                    DateTime exon = Convert.ToDateTime(_expireOn);

                    TimeSpan lefttime = exon - DateTime.Now;

                    if (lefttime.TotalMinutes > 0)
                    {
                        return $"{lefttime.Hours}h{lefttime.Minutes}m left";
                    }
                    else
                    {
                        return "Miss SLA";
                    }
                }
                catch
                {
                    return _expireOn;
                }
            }
            set { _expireOn = value; }
        }
        public string SAPString { get; set; }
        public string QueueName { get; set; }
        public string servicelevel { get; set; }
        public string Title { get; set; }
        public string Customers { get; set; }
        public string AllContents { get; set; }


        public CaseInfo()
        { }

        public CaseInfo(JToken caseInfo)
        {
            CaseID = caseInfo[0].ToString();
            Severity = caseInfo[5].ToString();
            ExpiresOn = caseInfo[15].ToString();
            SAPString = caseInfo[10].ToString();
            Customers = GenerateCustomerInfo(caseInfo[22]);
            QueueName = caseInfo[23].ToString();
            servicelevel = caseInfo[24].ToString();
            Title = caseInfo[27].ToString();

            AllContents = caseInfo.ToString();
        }


        public string GenerateCustomerInfo(JToken CustomersInfo)
        {
            try
            {
                string customer = "";
                JArray Contacts = JArray.Parse(CustomersInfo.ToString())[0]["Contacts"] as JArray;

                foreach (var c in Contacts)
                {
                    customer = "";
                    //FirstName \ LastName \ Email \Phone
                    customer += c.Value<string>("FirstName") ?? "";
                    customer += " " + c.Value<string>("LastName") ?? "";
                    customer += " " + c.Value<string>("Email") ?? "";
                    customer += " " + c.Value<string>("Phone") ?? "";

                    if (c["IsPrimaryContact"].ToString() == "True") break;
                }

                return customer;
            }
            catch (Exception ex)
            {
                return $"customer info exception {ex}";
            }
        }


        public string FormatCaseInfo()
        {

            return JsonConvert.SerializeObject(this);
            //return CaseID + "|" + Severity + "|" + ExpiresOn + "|" + Customers + "|" + QueueName + "|" + SAPString + "|" + servicelevel + "|" + Title;
        }
    }

    public class User
    {
        public string UserName { get; set; }
    }

    public class QueueInfo
    {

        public string QueueName { get; set; }

        public string EstsAuthPersistent { get; set; }

        public string QueryParameters { get; set; }

        public string Authorization { get; set; }
    }

    public class SAPMappingAlert
    {

        public string SAPString { get; set; }

        public List<User> AlertUsers { get; set; }
    }
}