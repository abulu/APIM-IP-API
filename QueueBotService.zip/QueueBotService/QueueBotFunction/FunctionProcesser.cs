using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Text;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using QueueBotService;

namespace QueueBotFunction
{
    public static class FunctionProcesser
    {
        private static IQueueClient queueClient;

        private static HttpClient client = new HttpClient();

        //Service Bus Info
        const string ServiceBusConnectionString = "Endpoint=sb://lbservicebus01.servicebus.chinacloudapi.cn/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=nMKlBzh80IDO3NrDbJzwdiHOy4qfvQdwzStciKcGeqs=";

        static string[,] podqueues = { { "Mooncake - VM PoD", "vmpodqueue" }, { "Mooncake - Dev PoD", "devpodqueue" }, { "Mooncake - App PoD", "apppodqueue" }, { "Mooncake - DB PoD", "dbpodqueue" }, { "Mooncake - Net PoD", "netpodqueue" } };


        [FunctionName("FunctionProcesser")]
        public static void Run([ServiceBusTrigger("newcasequeue", Connection = "ServiceBusConnectionStr")]string myQueueItem, ILogger log)
        {
            //Azure/Mooncake Support Escalation/Mooncake - VM PoD/Recovery Services


            string queueName = GetCasePodAndQueue(myQueueItem);


            SendCaseInfoToServiceBus(myQueueItem, queueName);


            log.LogInformation($"C# ServiceBus queue trigger function processed message in queue: {queueName}");

        }

        private static string GetCasePodAndQueue(string caseinfo)
        {
            string queueName = "otherpodqueue";

            var casearray = caseinfo.Split("|");

            if (casearray.Length >= 7)
            {
                //find the correct pod queue and get the service bus queue name
                for (int i = 0; i < podqueues.Length / podqueues.Rank; i++)
                {
                    if (casearray[3].Contains(podqueues[i, 0]))
                    {
                        queueName = podqueues[i, 1];
                    }
                }
            }

            return queueName;
        }

        private static void SendCaseInfoToServiceBus(string caseinfo, string queueName)
        {
            queueClient = new QueueClient(Environment.GetEnvironmentVariable("ServiceBusConnectionStr"), queueName);

            // Send messages.
            try
            {

                CaseInfo caseObj = JsonConvert.DeserializeObject<CaseInfo>(caseinfo);
                caseObj.AllContents = "";

                // Create a new message to send to the queue.
                string messageBody = $"Message : {caseinfo}";
                var message = new Message(Encoding.UTF8.GetBytes(caseinfo));


                // Write the body of the message to the console.
                Console.WriteLine($"Sending message to :{queueName} - {caseObj.CaseID}");

                // Send the message to the queue.
                queueClient.SendAsync(message);

                //https://qbotserver.azurewebsites.net/api/notify/Bu%20Lu?msg=this%20is%20a%20bot
                //test put the get result to bot service
                //https://lbmaker-bot.azurewebsites.net/api/notify/
                var geturl = "https://qbotserver.azurewebsites.net/api/notify/Bu%20Lu?msg=" + caseObj.FormatCaseInfo().Replace("/", "|");
                var result = client.GetAsync(geturl).Result;
                Console.WriteLine($"Get URL : {geturl}");

                Console.WriteLine($"Get result : {result.StatusCode}");

            }
            catch (Exception exception)
            {
                Console.WriteLine($"{DateTime.Now} :: Exception: {exception.Message}");
            }

            queueClient.CloseAsync();
        }
    }
}
