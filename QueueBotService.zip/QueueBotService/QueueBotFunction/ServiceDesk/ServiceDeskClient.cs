﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace QueueBotFunction.ServiceDesk
{
    public class ServiceDeskClient : IDisposable
    {
        private readonly HttpClient httpClient = new HttpClient();
        CookieBasedAuthenticationProvider authenticationProvider;

        public string QueryUrl { get; set; } = "https://api.support.microsoft.com/v0/queryidresult";
        public string BaseUrl { get; set; } = "https://api.support.microsoft.com/";
        public string SDBaseUrl { get; set; } = "https://servicedesk.microsoft.com/";

        public string ClientId { get; set; }

        public ServiceDeskClient(string cookie)
        {
            authenticationProvider = new CookieBasedAuthenticationProvider(cookie);
        }

        public void Dispose()
        {
            authenticationProvider = null;

            httpClient.Dispose();
        }

        private async Task<bool> ExecuteAsync(HttpRequestMessage httpRequest)
        {
            var response = await httpClient.SendAsync(httpRequest);
            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            throw new Exception(response.ReasonPhrase);
        }

        private async Task<T> ExecuteAsync<T>(HttpRequestMessage httpRequest, JsonSerializerSettings jsonSerializerSettings = null)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                try
                {

                    await authenticationProvider.AuthenticateRequest(httpRequest);

                    var response = await httpClient.SendAsync(httpRequest);
                    if (response.StatusCode == System.Net.HttpStatusCode.Forbidden || response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {

                    }
                    response.EnsureSuccessStatusCode();

                    string responseContent = await response.Content.ReadAsStringAsync();
                    if (jsonSerializerSettings != null)
                    {
                        return JsonConvert.DeserializeObject<T>(responseContent, jsonSerializerSettings);
                    }

                    if (typeof(T).Equals(typeof(String)))
                    {
                        return (T)Convert.ChangeType(responseContent, typeof(T));
                    }

                    return JsonConvert.DeserializeObject<T>(responseContent);
                }
                finally
                {
                    httpClient.Dispose();
                }
            }
        }


        public async Task<String> GetAllNewCaseAsync(string querycontent, string version = "v0")
        {

            //     const string apiurl = "https://api.support.microsoft.com/v0/queryidresult";
            var requestUri = $"{BaseUrl}{version}/queryidresult";
            HttpRequestMessage httpRequest = new HttpRequestMessage(HttpMethod.Post, requestUri);
            httpRequest.Headers.Add("Accept", "application/json, text/plain, */*");
            var content = new StringContent(querycontent, Encoding.UTF8, "application/json");
            httpRequest.Content = content;

            return await ExecuteAsync<String>(httpRequest);

        }



        //public async Task<SingleCaseEntity> GetSingleCaseAsync(string caseId, string version = "v2")
        //{
        //    var requestUri = $"{BaseUrl}{version}/cases/{caseId}";
        //    var httpRequest = new HttpRequestMessage(HttpMethod.Get, requestUri);
        //    return await ExecuteAsync<SingleCaseEntity>(httpRequest, SingleCaseEntityConverter.Settings);
        //}

        //public async Task<List<Labor>> GetCaseLaborsAsync(string caseId, string version = "v1")
        //{
        //    var requestUri = $"{BaseUrl}{version}/cases/{caseId}/labors";
        //    var httpRequest = new HttpRequestMessage(HttpMethod.Get, requestUri);
        //    return await ExecuteAsync<List<Labor>>(httpRequest, LaborConverter.Settings);
        //}


    }
}
