﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;

namespace QueueBotFunction.ServiceDesk
{
    public class FailedToRefreshTokenEventArgs : EventArgs
    {
        public Exception Exception { get; set; }
        public string Message { get; set; }
    }

    public class CookieBasedAuthenticationProvider : IAuthenticationProvider
    {
        public event EventHandler<FailedToRefreshTokenEventArgs> OnFailedToRefreshToken;
        internal static readonly string SDLoginUrlFormat = "https://login.microsoftonline.com/common/oauth2/authorize?response_type={0}&client_id={1}&redirect_uri={2}&state=e5e7271e-842a-4faf-89d6-43f06cf33b17&nux=1&domain_hint=common&client-request-id=289fd29d-d92c-4e64-b0c5-f2d63de06a67&x-client-SKU=Js&x-client-Ver=1.0.13&nonce={3}";

        private string cachedToken;

        private CookieContainer cookieContainer;

        public CookieBasedAuthenticationProvider(string cookie)
        {
            cookieContainer = new CookieContainer();
            cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("AADSSO", "NA|NoExtension"));
            // Store the cookie somewhere else later
            cookieContainer.Add(new Uri(@"https://login.microsoftonline.com"), new Cookie("ESTSAUTHPERSISTENT", cookie));
        }

        public async Task AuthenticateRequest(HttpRequestMessage request)
        {
            // Passing tenant ID to the sample auth provider to use as a cache key
            string accessToken = await GetAccessToken();
            // Append the access token to the request
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            // This header identifies the sample in the Microsoft Graph service. If extracting this code for your project please remove.
            // requestMessage.Headers.Add("SampleID", "aspnetcore-connect-sample");
        }

        public async Task<string> GetAccessToken()
        {
            if (!string.IsNullOrEmpty(cachedToken))
            {
                return cachedToken;
            }

            return await RefreshAccessToken();
        }

        public async Task<string> RefreshAccessToken()
        {
            string access_token = "";
            string token_url
                     = @"https://login.microsoftonline.com/common/oauth2/authorize?resource=56bc044c-7644-4be6-bc52-37d178b5a640&response_type=token&state=&client_id=56bc044c-7644-4be6-bc52-37d178b5a640&scope=c8b3e0dd-990b-4882-b119-acddfcaa7ace&redirect_uri=https://servicedesk.microsoft.com/";
         //   string redictUrl = HttpUtility.UrlEncode("https://servicedesk.microsoft.com/");
          //  var token_url = string.Format(SDLoginUrlFormat, "id_token", "56bc044c-7644-4be6-bc52-37d178b5a640", redictUrl, Guid.NewGuid().ToString());

            // Get Access Token
            {
                var handler = new HttpClientHandler()
                {
                    CookieContainer = cookieContainer,
                    AllowAutoRedirect = false
                };
                using (HttpClient client = new HttpClient(handler))
                {
                    try
                    {
                        HttpResponseMessage response = await client.GetAsync(token_url);
                        if (response.StatusCode == HttpStatusCode.Redirect)
                        {
                            string responseBody = await response.Content.ReadAsStringAsync();
                            var statuscode = response.StatusCode;
                            var headers = response.Headers;
                            var location = headers.Location;
                            cachedToken = access_token = location?.ToString().Split('=')[1].Split('&')[0];
                        }
                        else
                        {
                            OnFailedToRefreshToken?.Invoke(this, new FailedToRefreshTokenEventArgs() { Message = "Failed to refresh access token", Exception = new Exception(response.ReasonPhrase) });
                        }
                    }
                    catch (Exception e)
                    {
                        OnFailedToRefreshToken?.Invoke(this, new FailedToRefreshTokenEventArgs() { Message = "Failed to refresh access token", Exception = e });
                    }

                    client.Dispose();
                }
            }

            return access_token;
        }
    }
}
