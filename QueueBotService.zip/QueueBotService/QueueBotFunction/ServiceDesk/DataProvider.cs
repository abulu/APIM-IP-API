﻿using QueueBotService;
using System;
using System.Collections.Generic;
using System.Text;

namespace QueueBotFunction.ServiceDesk
{
    public class DataProvider : IDisposable
    {
        //Get all the Monitor Queue List 
        public List<QueueInfo> GetAllMonitorQueues()
        {

            //MOCK Data

            List<QueueInfo> qlist = new List<QueueInfo>() {
                new QueueInfo(){  QueueName ="Mooncake BC",
                    EstsAuthPersistent ="0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AgABAAQAAAAm-06blBE1TpVMil8KPQ41AADs_wEA9P-gPU-etm9uUnQwNz42LTXTOBzjXl4WCO3C8cam2hanvM7upZVK_13mvyXysdQLc2mgW-zjg-wFoFWUy6igL5XjaL_5TaVTaI8jrym13JFhhlYKT-UJwk2vhpV3Hc-uBqV9oo594NfPYT4yPtF46_eigGxDp0oyifXXUKfgNsZOASsek21DFeIA9FgJtsSEifv4KylcZnEfqR70X0PtvY7yCuIN4xJZ0qQ4ahxyxv44llEpcVnr15hbqdIWVF2C8bFhE9TBGKN0NUjf1s_GK97c6W0goOnRRmi_A8mw2TY1MQlfaI3Wp_Jrb1oeUrqjNimoiwUDCdkxoD5Dmnku9niChdzSE2ojR4z1MwKffiihewui3X8cDsdGH-vMyWHcoe_rbremY2IhtrcRa7O767LRSuGcuhwQWJYYj-UcNNLZIGWIAqhx0HZXBkgH18RQEykbZeeCipaYfNEqyUbZW3g14CG6XnbLu_ZcXxaS4vdlw9kp5d2PunC9lVwmIZNSCQfzWYQ-1N_xrTtMguosZ-T_dA2L_Vwc7ExHabXpU9dQEIk7EF4VxF7giUM4saxUPUbXwYPP_8AuVMhAb2ytq_JiK9XbcixoQVLx6Gf3z4_QJWYDleya_BRku0aqp32KnVo0yD6dj6jVR2aOsT9CtcZRNxsWGL7FMNbDA4_0ECf60TRgwqjDeslGbEkwMQwH1DSw6HlqV3EttVuXNA",
                    QueryParameters = "{\"query_parameters\":[{\"name\":\"aadUpn\",\"values\":[\"sypang@microsoft.com\"]},{\"name\":\"topCount\",\"values\":[\"100\"]}],\"queryid\":\"UNASSIGNED_CASES_MYCASES_TOPCOUNT\"}",
                    Authorization =""
                },
                new QueueInfo(){  QueueName ="Mooncake Premier",
                    EstsAuthPersistent ="0.AQEAv4j5cvGGr0GRqy180BHbR0wEvFZEduZLvFI30Xi1pkAaACA.AgABAAQAAAAm-06blBE1TpVMil8KPQ41AADs_wEA9P-gPU-etm9uUnQwNz42LTXTOBzjXl4WCO3C8cam2hanvM7upZVK_13mvyXysdQLc2mgW-zjg-wFoFWUy6igL5XjaL_5TaVTaI8jrym13JFhhlYKT-UJwk2vhpV3Hc-uBqV9oo594NfPYT4yPtF46_eigGxDp0oyifXXUKfgNsZOASsek21DFeIA9FgJtsSEifv4KylcZnEfqR70X0PtvY7yCuIN4xJZ0qQ4ahxyxv44llEpcVnr15hbqdIWVF2C8bFhE9TBGKN0NUjf1s_GK97c6W0goOnRRmi_A8mw2TY1MQlfaI3Wp_Jrb1oeUrqjNimoiwUDCdkxoD5Dmnku9niChdzSE2ojR4z1MwKffiihewui3X8cDsdGH-vMyWHcoe_rbremY2IhtrcRa7O767LRSuGcuhwQWJYYj-UcNNLZIGWIAqhx0HZXBkgH18RQEykbZeeCipaYfNEqyUbZW3g14CG6XnbLu_ZcXxaS4vdlw9kp5d2PunC9lVwmIZNSCQfzWYQ-1N_xrTtMguosZ-T_dA2L_Vwc7ExHabXpU9dQEIk7EF4VxF7giUM4saxUPUbXwYPP_8AuVMhAb2ytq_JiK9XbcixoQVLx6Gf3z4_QJWYDleya_BRku0aqp32KnVo0yD6dj6jVR2aOsT9CtcZRNxsWGL7FMNbDA4_0ECf60TRgwqjDeslGbEkwMQwH1DSw6HlqV3EttVuXNA",
                    QueryParameters = "{\"query_parameters\":[{\"name\":\"aadUpn\",\"values\":[\"sypang@microsoft.com\"]},{\"name\":\"topCount\",\"values\":[\"100\"]}],\"queryid\":\"UNASSIGNED_CASES_MYCASES_TOPCOUNT\"}",
                    Authorization =""
                }
            };

            return qlist;
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {

        }
    }
}
