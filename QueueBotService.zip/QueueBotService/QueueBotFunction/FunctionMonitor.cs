using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using QueueBotFunction.ServiceDesk;

namespace QueueBotService
{
    public static class FunctionMonitor
    {
        private static IQueueClient queueClient;


        //Call Service Desk Info
        const string apiurl = "https://api.support.microsoft.com/v0/queryidresult";
        ////const string contentValue = "{\"query_parameters\":[{\"name\":\"selectedRCID\",\"values\":[\"7f624f7a-6a9a-e711-812f-002dd8151753\",\"e196a1b2-3800-e311-8cff-002dd8070232\",\"c643bfd6-817e-e811-8130-002dd821504c\"]},{\"name\":\"severity\",\"values\":[\"1\",\"2\",\"3\",\"4\"]},{\"name\":\"aadUpn\",\"values\":[\"bulu@microsoft.com\"]}],\"queryid\":\"UNASSIGNED_CASES_MYCASES\"}";
        //const string contentValue = "{\"query_parameters\":[{\"name\":\"aadUpn\",\"values\":[\"sypang@microsoft.com\"]},{\"name\":\"topCount\",\"values\":[\"100\"]}],\"queryid\":\"UNASSIGNED_CASES_MYCASES_TOPCOUNT\"}";

        [FunctionName("FunctionMonitor")]
        public static async void Run([TimerTrigger("0 */1 * * * *")]TimerInfo myTimer, ILogger log)
        {
            try
            {
                using (DataProvider dataProvier = new DataProvider())
                {
                    var qlist = dataProvier.GetAllMonitorQueues();

                    //Foreach all the queue list and get the SD new case information
                    foreach (var queueinfo in qlist)
                    {
                        var cookie = queueinfo.EstsAuthPersistent;
                        //Try to get the authorization
                        log.LogInformation($"{queueinfo.QueueName}'s Cookie:{cookie}");

                        using (ServiceDeskClient serviceDeskClient = new ServiceDeskClient(cookie))
                        {
                            var responseString = await serviceDeskClient.GetAllNewCaseAsync(queueinfo.QueryParameters);

                            List<CaseInfo> caseList = GenerateCaseInfoBySDArray(responseString);

                            //Send case to Service Bus
                            SendCaseInfoToServiceBus(caseList);

                            log.LogInformation($"{queueinfo.QueueName}'s New Case Number: {caseList.Count}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.LogError($"Exception: {ex}");
            }
        }

        private static List<CaseInfo> GenerateCaseInfoBySDArray(string sdresult)
        {
            //Transfer to Json and get the table_parameter_result in table_parameters
            var details = JObject.Parse(sdresult);
            var resultTableObj = details["table_parameters"][0];

            List<CaseInfo> caseList = new List<CaseInfo>();

            if (resultTableObj != null && Int32.Parse(resultTableObj["row_count"].ToString()) > 0)
            {
                foreach (var caseInfo in resultTableObj["table_parameter_result"])
                {
                    caseList.Add(new CaseInfo(caseInfo));
                    //////CaseID + Severity + ExpiresOn + SAPString + QueueName + servicelevel+ Title
                    //caseList.Add(caseInfo[0].ToString() + "|" + caseInfo[5].ToString() + "|" + caseInfo[15].ToString() + "|"
                    //            + caseInfo[10].ToString() + "|" + caseInfo[23].ToString() + "|" + caseInfo[24].ToString() + "|"
                    //            + caseInfo[27].ToString());
                    ////log.LogInformation($" Result: {caseInfo.ToString() }");
                }
            }
            //return the case info list
            return caseList;
        }

        private static void SendCaseInfoToServiceBus(List<CaseInfo> caseList)
        {
            queueClient = new QueueClient(Environment.GetEnvironmentVariable("ServiceBusConnectionStr"), Environment.GetEnvironmentVariable("NewCaseQueueName"));

            foreach (var caseinfo in caseList)
            {
                // Send messages.
                try
                {
                    // Create a new message to send to the queue.                    
                    var message = new Message(Encoding.UTF8.GetBytes(caseinfo.FormatCaseInfo()));

                    // Write the body of the message to the console.
                    Console.WriteLine($"Message : {caseinfo.CaseID}");

                    // Send the message to the queue.
                    queueClient.SendAsync(message);

                }
                catch (Exception exception)
                {
                    Console.WriteLine($"{DateTime.Now} :{caseinfo.CaseID}: Exception: {exception.Message}");
                }
            }
            queueClient.CloseAsync();
        }
    }
}
