﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace QueueBotService.Controllers
{
    [Route("api/notify")]
    [ApiController]
    public class NotifyController : ControllerBase
    {
        private string message = "?";
        private string caseurl = "https://servicedesk.microsoft.com/#/customer/cases?caseNumber=";
        private readonly IBotFrameworkHttpAdapter _adapter;
        private readonly string _appId;
        private readonly ConcurrentDictionary<string, ConversationReference> _conversationReferences;

        public NotifyController(IBotFrameworkHttpAdapter adapter, IConfiguration configuration, ConcurrentDictionary<string, ConversationReference> conversationReferences)
        {
            _adapter = adapter;
            _conversationReferences = conversationReferences;
            _appId = configuration["MicrosoftAppId"];

            // If the channel is the Emulator, and authentication is not in use,
            // the AppId will be null.  We generate a random AppId for this case only.
            // This is not required for production, since the AppId will have a value.
            if (string.IsNullOrEmpty(_appId))
            {
                _appId = Guid.NewGuid().ToString(); //if no AppId, use a random Guid
            }
        }


        [Route("[action]")]
        [HttpGet]
        public IActionResult GetAllUsers()
        {
            return new ContentResult()
            {
                Content = _conversationReferences.Values.Count > 0 ? JsonConvert.SerializeObject(_conversationReferences.Values) : "No User",
                ContentType = "text/html",
                StatusCode = (int)HttpStatusCode.OK,
            };
        }


        [HttpGet("{userid}")]
        public async Task<IActionResult> Get(string userid, [FromQuery]string msg)
        {
            string pageconversationinfo = "";
            message = msg;

            foreach (var conversationReference in _conversationReferences.Values)
            {
                if (conversationReference.User.Name.ToLower() == userid.ToLower())
                {
                    pageconversationinfo = $"Send message to : {userid}";
                    //conversationinfo = conversationReference.User.ToString();
                    await ((BotAdapter)_adapter).ContinueConversationAsync(_appId, conversationReference, BotCallback, default(CancellationToken));

                    break;
                }
                pageconversationinfo = $"Cannot find this user : {userid}";
            }

            // Let the caller know proactive messages have been sent
            return new ContentResult()
            {
                Content = pageconversationinfo,
                ContentType = "text/html",
                StatusCode = (int)HttpStatusCode.OK,
            };
        }


        [HttpGet]
        public async Task<IActionResult> Get([FromQuery]string msg)
        {
            message = msg;

            foreach (var conversationReference in _conversationReferences.Values)
            {
                await ((BotAdapter)_adapter).ContinueConversationAsync(_appId, conversationReference, BotCallback, default(CancellationToken));

            }

            // Let the caller know proactive messages have been sent
            return new ContentResult()
            {
                Content = "Message send to all users " + _conversationReferences.Values.Count.ToString(),
                ContentType = "text/html",
                StatusCode = (int)HttpStatusCode.OK,
            };
        }

        private async Task BotCallback(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            try
            {
                // If you encounter permission-related errors when sending this message, see
                // https://aka.ms/BotTrustServiceUrl
                //var reply = MessageFactory.Text("[Notify]:" + message);
                //JsonConvert.DeserializeObject
                var caseInfo = JObject.Parse(message);
                var caseid = caseInfo["CaseID"].ToString();
                caseurl = caseurl + caseid;

                //CaseID + "|" + Severity + "|" + ExpiresOn + "|" + Customers + "|" + QueueName + "|" + SAPString + "|" + servicelevel + "|" + Title;


                var frow = caseInfo["CaseID"].ToString() + "***" + caseInfo["Severity"].ToString() + "***" + caseInfo["ExpiresOn"].ToString();
                var srow = caseInfo["Customers"].ToString();
                var trow = caseInfo["QueueName"].ToString() + "***" + caseInfo["SAPString"].ToString() + "***" + caseInfo["servicelevel"].ToString() + "***" + caseInfo["Title"].ToString();

                await turnContext.SendActivityAsync($"<div style='color:red'><strong>[New Case info] :::::: {frow}</strong></div><br> {srow} <br> {trow} <br><div>Go to case <a href='{caseurl}'> {caseid} </div>");
            }
            catch (Exception ex)
            {
                await turnContext.SendActivityAsync(ex.Message);
            }
        }
    }
}