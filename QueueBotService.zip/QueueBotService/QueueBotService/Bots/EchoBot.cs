// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.6.2

using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

namespace QueueBotService.Bots
{
    public class EchoBot : ActivityHandler
    {
        private readonly ConcurrentDictionary<string, ConversationReference> _conversationReferences;

        public EchoBot(ConcurrentDictionary<string, ConversationReference> conversationReferences)
        {
            _conversationReferences = conversationReferences;
        }


        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            string result = "";
            try
            {
                var conversationReference = turnContext.Activity.GetConversationReference();
                _conversationReferences.AddOrUpdate(conversationReference.User.Id, conversationReference, (key, newValue) => conversationReference);
            }
            catch (System.Exception ex)
            {
                result = ex.Message;
            }

            if (string.Equals(turnContext.Activity.Text, "wait", System.StringComparison.InvariantCultureIgnoreCase))
            {
                await turnContext.SendActivitiesAsync(
                    new Activity[] {
                new Activity { Type = ActivityTypes.Typing },
                new Activity { Type = "delay", Value= 3000 },
                MessageFactory.Text("Finished typing", "Finished typing"),
                    },
                    cancellationToken);
            }
            else
            {

                var replyText = $"Echo: {turnContext.Activity.Text}. Say 'wait' to watch me type." + result;
                await turnContext.SendActivityAsync(MessageFactory.Text(replyText, replyText), cancellationToken);

                //await SendSuggestedActionsAsync(turnContext, cancellationToken);
            }
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            var welcomeText = "Hello and welcome to Mooncake Queue Bot Services!";
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text(welcomeText, welcomeText), cancellationToken);
                }
            }
        }

        private void AddConversationReference(Activity activity)
        {
            var conversationReference = activity.GetConversationReference();
            _conversationReferences.AddOrUpdate(conversationReference.User.Id, conversationReference, (key, newValue) => conversationReference);
        }

        protected override Task OnConversationUpdateActivityAsync(ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            AddConversationReference(turnContext.Activity as Activity);

            return base.OnConversationUpdateActivityAsync(turnContext, cancellationToken);
        }


        // Creates and sends an activity with suggested actions to the user. When the user
        /// clicks one of the buttons the text value from the "CardAction" will be
        /// displayed in the channel just as if the user entered the text. There are multiple
        /// "ActionTypes" that may be used for different situations.
        private static async Task SendSuggestedActionsAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            var reply = MessageFactory.Text("What is your favorite color?");

            //var reply = MessageFactory.Text("Welcome to CardBot."
            //          + " This bot will show you different types of Rich Cards."
            //          + " Please type anything to get started.");

            reply.SuggestedActions = new SuggestedActions()
            {
                Actions = new List<CardAction>()
                            {
                                new CardAction() { Title = "Red", Type = ActionTypes.ImBack, Value = "Red" },
                                new CardAction() { Title = "Yellow", Type = ActionTypes.ImBack, Value = "Yellow" },
                                new CardAction() { Title = "Blue", Type = ActionTypes.ImBack, Value = "Blue" },
                            },
            };
            await turnContext.SendActivityAsync(reply, cancellationToken);
        }
    }
}
